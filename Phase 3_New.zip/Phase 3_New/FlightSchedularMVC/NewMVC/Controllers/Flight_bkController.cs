﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using NewMVC.Models;

namespace NewMVC.Controllers
{
    public class Flight_bkController : Controller
    {
        private Ashraf_46000153Entities db = new Ashraf_46000153Entities();

        // GET: Flight_bk
        public ActionResult Index()
        {
            var flight_bk = db.Flight_bk.Include(f => f.AirportTerminal_bk).Include(f => f.FlightDeparture_bk).Include(f => f.FlightStatus_bk);
            return View(flight_bk.ToList());
        }

        public ActionResult DetailsMenu()
        {
            var flight_bk = db.Flight_bk.Include(f => f.AirportTerminal_bk).Include(f => f.FlightDeparture_bk).Include(f => f.FlightStatus_bk);
            return View(flight_bk.ToList());
        }

        // GET: Flight_bk/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_bk flight_bk = db.Flight_bk.Find(id);
            if (flight_bk == null)
            {
                return HttpNotFound();
            }
            return View(flight_bk);
        }

        // GET: Flight_bk/Create
        public ActionResult Create()
        {
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName");
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_bk, "ID", "ID");
            ViewBag.StatusId = new SelectList(db.FlightStatus_bk, "ID", "Description");
            return View();
        }


        public ActionResult Viewall()
        {
            var flight_bk = db.Flight_bk.Include(f => f.AirportTerminal_bk).Include(f => f.FlightDeparture_bk).Include(f => f.FlightStatus_bk);
            return View(flight_bk.ToList());
        }

        // POST: Flight_bk/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Name,Destination,DepartureId,TerminalId,GateNo,StatusId")] Flight_bk flight_bk)
        {
            if (ModelState.IsValid)
            {
                db.Flight_bk.Add(flight_bk);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.TerminalId = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName", flight_bk.TerminalId);
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_bk, "ID", "ID", flight_bk.DepartureId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_bk, "ID", "Description", flight_bk.StatusId);
            return View(flight_bk);
        }

        // GET: Flight_bk/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_bk flight_bk = db.Flight_bk.Find(id);
            if (flight_bk == null)
            {
                return HttpNotFound();
            }
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName", flight_bk.TerminalId);
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_bk, "ID", "ID", flight_bk.DepartureId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_bk, "ID", "Description", flight_bk.StatusId);
            return View(flight_bk);
        }

        // POST: Flight_bk/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Name,Destination,DepartureId,TerminalId,GateNo,StatusId")] Flight_bk flight_bk)
        {
            if (ModelState.IsValid)
            {
                db.Entry(flight_bk).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName", flight_bk.TerminalId);
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_bk, "ID", "ID", flight_bk.DepartureId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_bk, "ID", "Description", flight_bk.StatusId);
            return View(flight_bk);
        }

        // GET: Flight_bk/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_bk flight_bk = db.Flight_bk.Find(id);
            if (flight_bk == null)
            {
                return HttpNotFound();
            }
            return View(flight_bk);
        }

        // POST: Flight_bk/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Flight_bk flight_bk = db.Flight_bk.Find(id);
            db.Flight_bk.Remove(flight_bk);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
