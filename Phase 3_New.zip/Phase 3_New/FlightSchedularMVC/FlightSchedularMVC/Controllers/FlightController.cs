﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FlightSchedularMVC.Models;
using System.Net;
using System.Data.Entity;

namespace FlightSchedularMVC.Controllers
{
    public class FlightController : Controller
    {
        private FlightEntities3 db = new FlightEntities3();
        // GET: Flight
        public ActionResult Index()
        {
            var flights = db.Flight_bk.Include(e => e.AirportTerminal_bk).Include(e => e.FlightDeparture_bk).Include(e => e.FlightStatus_bk);
            return View(flights.ToList());
        }

        public ActionResult Create()
        {
            //var flights = db.Flight_bk.Include(e => e.AirportTerminal_bk).Include(e => e.FlightDeparture_bk).Include(e => e.FlightStatus_bk);
            return View();
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Flight_bk flight = db.Flight_bk.Find(id);

            if (flight == null)
            {
                HttpNotFound();
            }

            return View(flight);
        }

        public ActionResult Edit(int? id)
        {

            if (id != null)
            {

                Flight_bk flight = db.Flight_bk.Find(id);

                ViewBag.Status = new SelectList(db.FlightStatus_bk, "ID", "Description", flight.StatusId);
                ViewBag.TerminalName = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName", flight.TerminalId);
                return View(flight);
            }

            return View();
        }
        [HttpPost]
        public ActionResult Edit([Bind(Include = "Name,Destination,DepartureId,TerminalId,GateNo,StatusId,FlightDeparture_bk,AirportTerminal_bk,FlightStatus_bk")]Flight_bk flight)
        {
            if (ModelState.IsValid)
            {
                FlightDeparture_bk dept = db.FlightDeparture_bk.Where(x => x.ID == flight.DepartureId).FirstOrDefault();
                dept.Scheduled = flight.FlightDeparture_bk.Scheduled;
                dept.Estimated = flight.FlightDeparture_bk.Estimated;
                
                db.Entry(dept).State = EntityState.Modified;
                db.SaveChanges();
                db.Entry(flight).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Status = new SelectList(db.FlightStatus_bk, "ID", "Description");
            ViewBag.TerminalName = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName");
            return View(flight);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Flight_bk flight = db.Flight_bk.Find(id);
            if (id == null)
            {
                HttpNotFound();
            }

            return View(flight);
        }

    }
}