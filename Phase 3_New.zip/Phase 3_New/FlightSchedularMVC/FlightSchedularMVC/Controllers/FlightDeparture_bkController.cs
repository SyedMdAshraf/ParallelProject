﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using FlightSchedularMVC.Models;

namespace FlightSchedularMVC.Controllers
{
    public class FlightDeparture_bkController : Controller
    {
        private FlightEntities3 db = new FlightEntities3();

        // GET: FlightDeparture_bk
        public ActionResult Index()
        {
            return View(db.FlightDeparture_bk.ToList());
        }

        // GET: FlightDeparture_bk/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FlightDeparture_bk flightDeparture_bk = db.FlightDeparture_bk.Find(id);
            if (flightDeparture_bk == null)
            {
                return HttpNotFound();
            }
            return View(flightDeparture_bk);
        }

        // GET: FlightDeparture_bk/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: FlightDeparture_bk/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Scheduled,Estimated,Actual")] FlightDeparture_bk flightDeparture_bk)
        {
            if (ModelState.IsValid)
            {
                db.FlightDeparture_bk.Add(flightDeparture_bk);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(flightDeparture_bk);
        }

        // GET: FlightDeparture_bk/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FlightDeparture_bk flightDeparture_bk = db.FlightDeparture_bk.Find(id);
            if (flightDeparture_bk == null)
            {
                return HttpNotFound();
            }
            return View(flightDeparture_bk);
        }

        // POST: FlightDeparture_bk/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Scheduled,Estimated,Actual")] FlightDeparture_bk flightDeparture_bk)
        {
            if (ModelState.IsValid)
            {
                db.Entry(flightDeparture_bk).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(flightDeparture_bk);
        }

        // GET: FlightDeparture_bk/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FlightDeparture_bk flightDeparture_bk = db.FlightDeparture_bk.Find(id);
            if (flightDeparture_bk == null)
            {
                return HttpNotFound();
            }
            return View(flightDeparture_bk);
        }

        // POST: FlightDeparture_bk/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            FlightDeparture_bk flightDeparture_bk = db.FlightDeparture_bk.Find(id);
            db.FlightDeparture_bk.Remove(flightDeparture_bk);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
