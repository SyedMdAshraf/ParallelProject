use Ashraf_46000153
go

CREATE TABLE [dbo].[AirportTerminal_bk](
    [ID] [int] IDENTITY(400,1) NOT NULL,
    [TerminalName] [varchar](50) NULL,
    [AiportName] [varchar](50) NOT NULL,
    [ContactNo] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
    [TerminalName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[FlightStatus_bk](
    [ID] [int] IDENTITY(200,1) NOT NULL,
    [Description] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
    [Description] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[FlightOperators_bk](
    [ID] [int] IDENTITY(300,1) NOT NULL,
    [Name] [varchar](50) NULL,
    [HeadOffice] [varchar](50) NOT NULL,
    [ContactNo] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
    [Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[FlightDeparture_bk](
    [ID] [int] IDENTITY(500,1) NOT NULL,
    [Scheduled] [datetime] NOT NULL,
    [Estimated] [datetime] NOT NULL,
    [Actual] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[Flight_bk](
    [ID] [int] IDENTITY(100,1) NOT NULL,
    [Name] [varchar](50) NULL,
    [Destination] [varchar](30) NOT NULL,
    [DepartureId] [int] NULL,
    [TerminalId] [int] NULL,
    [GateNo] [varchar](30) NOT NULL,
    [StatusId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
    [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Flight_bk]  WITH CHECK ADD FOREIGN KEY([DepartureId])
REFERENCES [dbo].[FlightDeparture_bk] ([ID])
GO

ALTER TABLE [dbo].[Flight_bk]  WITH CHECK ADD FOREIGN KEY([Name])
REFERENCES [dbo].[FlightOperators_bk] ([Name])
GO

ALTER TABLE [dbo].[Flight_bk]  WITH CHECK ADD FOREIGN KEY([StatusId])
REFERENCES [dbo].[FlightStatus_bk] ([ID])
GO

ALTER TABLE [dbo].[Flight_bk]  WITH CHECK ADD FOREIGN KEY([TerminalId])
REFERENCES [dbo].[AirportTerminal_bk] ([ID])
GO


create procedure [dbo].[InsertFlight_4317]
(
@Name varchar(50),
@Destination varchar(30),
@Scheduled DateTime,
@Estimated DateTime,
@Actual DateTime,
@TerminalId int,
@GateNo varchar(50),
@StatusId int
)
as
begin
Insert into FlightDeparture_4317 values(@Scheduled, @Estimated, @Actual) 
Insert into Flight_4317 values(@Name, @Destination, (select max(ID) from FlightDeparture_4317),@TerminalId, @GateNo, @StatusId )
end

create procedure [dbo].[UpdateFlight_4317]
(
@ID int,
@Name varchar(50),
@Destination varchar(30),
@Scheduled DateTime,
@Estimated DateTime,
@Actual DateTime,
@TerminalId int,
@GateNo varchar(50),
@StatusId int
)
as
begin
Insert into FlightDeparture_4317 values(@Scheduled, @Estimated, @Actual) 
Update Flight_4317 set  Name= @Name, Destination= @Destination, DepartureId = ((select max(FlightDeparture_4317.ID) from FlightDeparture_4317)) , TerminalId = @TerminalId, GateNo = @GateNo, StatusId = @StatusId where ID=@ID
end

create procedure [dbo].[DeleteFlight_4317]
(@ID int)
as
begin
delete from Flight_4317 where ID=@ID
end

create procedure [dbo].[GetAllFlights_4317] 
as
begin
select * from Flight_4317  fb inner join FlightDeparture_4317 fd on fb.DepartureId = fd.ID 
end