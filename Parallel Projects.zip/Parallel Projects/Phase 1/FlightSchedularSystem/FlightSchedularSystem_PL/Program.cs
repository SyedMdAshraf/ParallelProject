﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlightSchedularSystem_BusinessLayer;
using FlightSchedularSystem_Entities;
using FlightSchedularSystem_Exception;

namespace FlightSchedularSystem_PL
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch;
            do
            {
                PrintMenu();
                Console.WriteLine("Please Enter Your Choice : ");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        AddFlight();
                        break;
                    case 2:
                        UpdateFlight();
                        break;
                    case 3:
                        DeleteFlight();
                        break;
                    case 4:
                        SearchFlight();
                        break;
                    case 5:
                        ListAllFlights();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice !");
                        break;

                }
            }
            while (ch != -1);
            
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n~~~~~~~~~~Flight Schedular System~~~~~~~~~~\n");
            Console.WriteLine("Press 1: To Add Flight");
            Console.WriteLine("Press 2: To Update Flight");
            Console.WriteLine("Press 3: To Delete Flight");
            Console.WriteLine("Press 4: To Search Flight");
            Console.WriteLine("Press 5: To List All Flight");
            Console.WriteLine("Press 6: To Quit Flight Schedular System");
            Console.WriteLine("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

        }

        private static void AddFlight()
        {
            try
            {
                FlightEntities newFlight = new FlightEntities();
                Console.Write("Enter the Flight No : ");
                newFlight.FlightNo = Console.ReadLine();
                Console.Write("Enter the Flight Name : ");
                newFlight.Name = Console.ReadLine();
                Console.Write("Enter Destination : ");
                newFlight.Destination = Console.ReadLine();
                Console.Write("Enter Departure Date : ");//Take Scheduled DateTime Only

                Dept departure=new Dept();
                departure.Scheduled = DateTime.Parse(Console.ReadLine());
                departure.Estimated = departure.Scheduled;
                departure.Actual = departure.Scheduled;
                newFlight.Departure = departure;

                Console.Write("Enter Terminal : ");
                newFlight.Terminal = Console.ReadLine();
                Console.Write("Enter Gate No : ");
                newFlight.GateNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Status : ");
                newFlight.Status = Console.ReadLine();
                bool flightAdded = FlightBL.AddFlightBL(newFlight);
                if(flightAdded)
                    Console.WriteLine("\nFlight Added Successfully !");
                if (!flightAdded)
                    Console.WriteLine("\nFlight Not Added.");
            }
            catch(FlightException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void UpdateFlight()
        {
            try
            {
                string updateFlightNo;
                Console.WriteLine("Enter Flight No to Update Details : ");
                updateFlightNo = Console.ReadLine();
                FlightEntities updatedFlight = FlightBL.SearchFlightBL(updateFlightNo);
                if (updatedFlight != null)
                {
                    Console.Write("Update Destination : ");
                    updatedFlight.Destination = Console.ReadLine();
                    Console.Write("Update Departure Time : ");

                    Dept departure = new Dept();
                    departure.Estimated = DateTime.Parse(Console.ReadLine());
                    departure.Actual = departure.Estimated;
                    updatedFlight.Departure = departure;

                    Console.Write("Update Terminal : ");
                    updatedFlight.Terminal = Console.ReadLine();
                    Console.Write("Update Gate No");
                    updatedFlight.GateNo = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Update Status");
                    updatedFlight.Status = Console.ReadLine();

                    bool flightUpdated = FlightBL.UpdateFlightBL(updatedFlight);
                    if (flightUpdated)
                        Console.WriteLine("\nFlight Details Updated Successfully !");
                    else
                        Console.WriteLine("\nFlight Details Not Updated.");
                }
                else
                {
                    Console.WriteLine("\nFlight Details Not Available");
                }
            }
            catch (FlightException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void DeleteFlight()
        {
            try
            {
                string deleteFlightNo;
                Console.Write("Enter Flight No to Delete : ");
                deleteFlightNo = Console.ReadLine();
                FlightEntities deleteFlight = FlightBL.SearchFlightBL(deleteFlightNo);
                if(deleteFlight !=null)
                {
                    bool flightdeleted = FlightBL.DeleteFlightBL(deleteFlightNo);
                    if(flightdeleted)
                        Console.WriteLine("\nFlight Deleted !");
                    else
                        Console.WriteLine("\nFlight Not Deleted.");
                }
                else
                {
                    Console.WriteLine("\nFlight Details Not Available");
                }

            }
            catch(FlightException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void SearchFlight()
        {
            try
            {
                string searchFlightNo ;
                Console.Write("Enter Flight No to Search : ");
                searchFlightNo = Console.ReadLine();
                FlightEntities searchFlight = FlightBL.SearchFlightBL(searchFlightNo);
                if (searchFlight != null)
                {
                    Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    Console.WriteLine("Flight No \tFlight Name \tDestination \tScheduled Departure \tExpected Departure \tActual Departure \tTerminal \tGate No \tStatus");
                    Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}", searchFlight.FlightNo, searchFlight.Name, searchFlight.Destination,searchFlight.Departure.Scheduled
                        ,searchFlight.Departure.Estimated,searchFlight.Departure.Actual,searchFlight.Terminal,searchFlight.GateNo,searchFlight.Status);
                    Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                }
                else
                {
                    Console.WriteLine("Flight Details Not Available");
                }

            }
            catch (FlightException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void ListAllFlights()
        {
            try
            {
                List<FlightEntities> flightList = FlightBL.GetAllFlightsBL();
                if (flightList != null)
                {
                    Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    Console.WriteLine("Flight No \t\tFlight Name \t\tDestination \t\tScheduled Departure \t\tExpected Departure \t\tActual Departure \t\tTerminal \t\tGate No \t\tStatus");
                    Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    foreach (FlightEntities flight in flightList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}", flight.FlightNo, flight.Name, flight.Destination, flight.Departure.Scheduled
                        , flight.Departure.Estimated, flight.Departure.Actual, flight.Terminal, flight.GateNo, flight.Status);
                    }
                    Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                }
                else
                {
                    Console.WriteLine("Flight Details Not Available");
                }
            }
            catch (FlightException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }



    }
}
