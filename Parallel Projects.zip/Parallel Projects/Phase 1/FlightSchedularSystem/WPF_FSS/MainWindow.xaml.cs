﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_FSS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static MainWindow AppWindow;
        public MainWindow()
        {
            InitializeComponent();
            AppWindow = this;
        }

       

        private void btnFlightMenu_Click(object sender, RoutedEventArgs e)
        {
            FlightMenu fm = new FlightMenu();
            grdFSS.Children.Add(fm);
            Grid.SetRow(fm, 0);
            Grid.SetColumn(fm, 0);
            grdMainMenu.Visibility = Visibility.Collapsed;
        }

        private void btnQuit_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        public void showMenu()          //For showing the menu from outside function
        {
            grdMainMenu.Visibility = Visibility.Visible;
        }

    }
}
