﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Sql;
using System.Data.SqlClient;
using FlightException;
using Flight_Entity;
using BL;

namespace WPF
{
    /// <summary>
    /// Interaction logic for AddFlight.xaml
    /// </summary>
    public partial class AddFlight : Window
    {
        public AddFlight()
        {
            SqlConnection sqlConnection = new SqlConnection("data source=NDAMSSQL\\SQLILEARN;initial catalog=Training_13Aug19_Pune;persist security info=True;user id=sqluser;password = sqluser");
            InitializeComponent();
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand("Select TerminalName from AirportTerminal_46000153", sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                cmbTerminal.Items.Add(reader[0]);
            }
            reader.Close();
            //-------------
            SqlCommand sqlCommand1 = new SqlCommand("Select Description from FlightStatus_46000153", sqlConnection);
            SqlDataReader reader1 = sqlCommand1.ExecuteReader();
            while (reader1.Read())
            {
                cmbStatus.Items.Add(reader1[0]);
            }
            reader1.Close();
            //---------------
            SqlCommand sqlCommand2 = new SqlCommand("Select Name from FlightOperators_46000153", sqlConnection);
            SqlDataReader reader2 = sqlCommand2.ExecuteReader();
            while (reader2.Read())
            {
                cmbName.Items.Add(reader2[0]);
            }
            reader2.Close();


            sqlConnection.Close();


        }



        private void BtnAddFlight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Flight_46000153 newFlight = new Flight_46000153();
                //newFlight.FlightID = Convert.ToInt32(txtID.Text);
                newFlight.Destination = txtDestination.Text;
                newFlight.GateNo = txtGateNo.Text;
                newFlight.Name = cmbName.Text;
                newFlight.StatusId = cmbStatus.SelectedIndex + 200;
                newFlight.TerminalId = cmbTerminal.SelectedIndex + 400;
                newFlight.departure.Actual = dpActual.SelectedDate;
                newFlight.departure.Estimated = dpEstimated.SelectedDate;
                newFlight.departure.Scheduled = dpScheduled.SelectedDate;
                bool employeeAdded = FlightBL.AddFlightBL(newFlight);
                if (employeeAdded)
                {   MessageBox.Show("Flight Added");
                }
                else
                    MessageBox.Show("Flight could not be Added");
            }
            catch (FtException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
