﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FlightException;
using BL;
using Flight_Entity;
using System.Data;

namespace WPF
{
    /// <summary>
    /// Interaction logic for GetAllFlights.xaml
    /// </summary>
    public partial class GetAllFlights : Window
    {
        public GetAllFlights()
        {
            InitializeComponent();
            try
            {
                List<Flight_46000153> flightList = new List<Flight_46000153>();
                flightList = FlightBL.GetAllFlightsBL();
                DataTable dt = new DataTable();
                dt.Columns.Add("Flight Name");
                dt.Columns.Add("Destination");
                dt.Columns.Add("Scheduled Departure");
                dt.Columns.Add("Estimated Departure");
                dt.Columns.Add("Actual Departure");
                dt.Columns.Add("Terminal ID");
                dt.Columns.Add("Gate No");
                dt.Columns.Add("Status ID");
                foreach(Flight_46000153 flight in flightList)
                {
                    dt.Rows.Add(new object[] { flight.Name, flight.Destination, flight.departure.Scheduled, flight.departure.Estimated, flight.departure.Actual,flight.TerminalId,flight.GateNo,flight.StatusId });
                }
                MyDataGrid.ItemsSource = dt.DefaultView;
            }
            catch (FtException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
