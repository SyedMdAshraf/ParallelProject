﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightException
{
    public class FtException:ApplicationException
    {
        public FtException(string message) : base(message)
        {
        }

        public FtException()
        {
            
        }
    }
}
