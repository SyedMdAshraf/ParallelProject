use Training_13Aug19_Pune
go


create table AirportTerminal_46000153
(
ID int primary key identity(400,1),
TerminalName varchar(50) unique,
AiportName varchar(50) not null,
ContactNo varchar(50) not null
)




create table FlightOperators_46000153
(
ID int primary key identity(300,1),
Name varchar(50) unique,
HeadOffice varchar(50) not null,
ContactNo varchar(50) not null
)

create table FlightStatus_46000153
(
ID int primary key identity(200,1),
Description varchar(50) unique
)


create table FlightDeparture_46000153
(
ID int primary key identity(500,1),
Scheduled DateTime not null,
Estimated DateTime not null,
Actual DateTime not null
)


create table Flight_46000153
(
ID int primary key identity(100,1),
Name varchar(50) foreign key(Name) references FlightOperators_46000153(Name),
Destination  varchar(30) not null,
DepartureId int foreign key(DepartureId) references FlightDeparture_46000153(ID),
TerminalId int foreign key(TerminalId) references AirportTerminal_46000153(ID),
GateNo varchar(30) not null,
StatusId int foreign key(StatusId) references FlightStatus_46000153(ID)
)


create procedure InsertFlight_46000153
(
@Name varchar(50),
@Destination varchar(30),
@Scheduled DateTime,
@Estimated DateTime,
@Actual DateTime,
@TerminalId int,
@GateNo varchar(50),
@StatusId int
)
as
begin
Insert into FlightDeparture_46000153 values(@Scheduled, @Estimated, @Actual) 
Insert into Flight_46000153 values(@Name, @Destination, (select max(ID) from FlightDeparture_46000153),@TerminalId, @GateNo, @StatusId )
end



select count(ID) from FlightDeparture_46000153


select * from Flight_46000153 where ID=101


create procedure UpdateFlight_46000153
(
@ID int,
@Name varchar(50),
@Destination varchar(30),
@Scheduled DateTime,
@Estimated DateTime,
@Actual DateTime,
@TerminalId int,
@GateNo varchar(50),
@StatusId int
)
as
begin
Insert into FlightDeparture_46000153 values(@Scheduled, @Estimated, @Actual) 
Update Flight_46000153 set  Name= @Name, Destination= @Destination, DepartureId = ((select max(FlightDeparture_46000153.ID) from FlightDeparture_46000153)) , TerminalId = @TerminalId, GateNo = @GateNo, StatusId = @StatusId where ID=@ID
end



create procedure DeleteFlight_46000153
(@ID int)
as
begin
delete from Flight_46000153 where ID=@ID
end

set identity_insert Flight_46000153 on
go


create procedure GetAllFlights_46000153 
as
begin
select * from Flight_46000153  fb inner join FlightDeparture_46000153 fd on fb.DepartureId = fd.ID 
end


select * from Flight_46000153 fb , FlightDeparture_46000153 fd , FlightStatus_46000153 fs where fb.DepartureId = fd.ID  and fs.ID = fb.StatusId ;
